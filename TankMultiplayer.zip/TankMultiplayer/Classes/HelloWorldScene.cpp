#include "HelloWorldScene.h"
//#include "PixelMap.h"

USING_NS_CC;

Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    if ( !Layer::init() )
    {
        return false;
    }
    auto sp = Sprite::create("test2.png");
//    map = RenderTexture::create(sp->getContentSize().width,sp->getContentSize().height, Texture2D::PixelFormat::RGB5A1);
//    map->setContentSize(sp->getContentSize());
//    Texture2D::setDefaultAlphaPixelFormat(Texture2D::PixelFormat::RGB5A1);
//    map->setSprite(sp);
//    Texture2D::setDefaultAlphaPixelFormat(Texture2D::PixelFormat::RGBA8888);
//    addChild(map);
    map = sp;
    addChild(map);
    map->setPosition(Point(300,400));
    //map->setAnchorPoint(Point(0,0));
    
    //debug touch
    auto listener = EventListenerTouchOneByOne::create();
    listener->onTouchBegan = CC_CALLBACK_2(HelloWorld::onTouchBegan, this);
    listener->onTouchEnded = CC_CALLBACK_2(HelloWorld::onTouchEnded, this);
    listener->onTouchMoved = CC_CALLBACK_2(HelloWorld::onTouchMoved, this);
    getEventDispatcher()->addEventListenerWithSceneGraphPriority(listener, this);
    
    
    circ = Sprite::create("circle.png");
    //circ->drawDot(Point(0,0), 30, Color4F(1,0,0,1));
    //circ->setContentSize(Size(30,30));
    addChild(circ);
    circ->setPosition(Point(300,400));
    
    
    scheduleUpdate();
    
    log("%f, %f", map->getContentSize().width, map->getContentSize().height);
    return true;
}

bool HelloWorld::onTouchBegan(Touch* touch, Event* event)
{
    circ->setPosition(touch->getLocation());
    return true;
}

void HelloWorld::onTouchMoved(Touch *touch, Event *event)
{
    circ->setPosition(touch->getLocation());
}

void HelloWorld::update(float dt)
{
    // check if dn bounding box collide with rt bounding box
    auto aabb1 = circ->getBoundingBox();
    auto aabb2 = map->getBoundingBox();
    //log("%f, %f, %f, %f", aabb2.origin.x, aabb2.origin.y, aabb2.size.width, aabb2.size.height);

    if(aabb1.intersectsRect(aabb2))
    {
        circ->setColor(Color3B(255,255,0));
    }
    else{
        circ->setColor(Color3B::WHITE);
    }
}